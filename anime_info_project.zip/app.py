from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/')
def home():
    query = request.args.get('q')
    anime_list = []
    if query:
        url = f'https://api.jikan.moe/v4/anime?q={query}&limit=10'
        res = requests.get(url).json()
        anime_list = res.get('data', [])
    return render_template('home.html', anime_list=anime_list, query=query)

@app.route('/anime/<int:anime_id>')
def anime_detail(anime_id):
    url = f'https://api.jikan.moe/v4/anime/{anime_id}'
    res = requests.get(url).json()
    anime = res.get('data', {})
    return render_template('anime.html', anime=anime)

if __name__ == '__main__':
    app.run(debug=True)